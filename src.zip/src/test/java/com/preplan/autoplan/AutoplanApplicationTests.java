package com.preplan.autoplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoplanApplicationTests {

	@Test
	void contextLoads() {
	}

}
