package com.preplan.autoplan.apiController;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
//    private final AuthService authService;

//    @PostMapping("/login")
//    public ResponseEntity<?> login(@RequestBody LoginDto loginDto) {
    // 로그인 로직
//    }

//    @PostMapping("/logout")
//    public ResponseEntity<?> logout() {
//         로그아웃 로직
//    }

    // 기타 인증 관련 엔드포인트
}