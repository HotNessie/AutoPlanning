package com.preplan.autoplan.dto;

import lombok.Getter;


@Getter
public class DayOffDto {
//    private Long id;
//    private Long areaId;
//    private LocalDateTime dayOffDate;

}