package com.preplan.autoplan.domain.global;

import jakarta.persistence.*;
import lombok.Getter;

@Embeddable
@Getter
public class Location {

    private String city;
    

//    시,군,구  시,구,  읍,면,동


}
