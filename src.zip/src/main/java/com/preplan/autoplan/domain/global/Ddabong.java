package com.preplan.autoplan.domain.global;

public abstract class Ddabong {
}
