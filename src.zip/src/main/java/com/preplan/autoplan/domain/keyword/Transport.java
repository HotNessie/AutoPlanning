package com.preplan.autoplan.domain.keyword;

public enum Transport {
    CAR, PUBLIC_TRANS
}
