package com.preplan.autoplan.domain.member;

public enum Sex {
    MALE, FEMALE
}
