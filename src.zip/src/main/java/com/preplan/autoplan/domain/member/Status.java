package com.preplan.autoplan.domain.member;

public enum Status {
    ACTIVE, DELETED
}
