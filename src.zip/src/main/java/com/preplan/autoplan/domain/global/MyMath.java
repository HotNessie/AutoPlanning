package com.preplan.autoplan.domain.global;

public interface MyMath {

    public void increment();

    public void decrement();
    
}
