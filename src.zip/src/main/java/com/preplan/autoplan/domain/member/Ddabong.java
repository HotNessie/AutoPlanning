package com.preplan.autoplan.domain.member;

public enum Ddabong {
    LIKE, NOT_LIKE, UNDEFINED;
}
