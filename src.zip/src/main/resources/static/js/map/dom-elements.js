export const searchInput = document.getElementById("searchInput");
export const resultsElement = document.getElementById("results");
export const suggestion = document.getElementById("suggestion");
export const searchButton = document.getElementById('searchButton');